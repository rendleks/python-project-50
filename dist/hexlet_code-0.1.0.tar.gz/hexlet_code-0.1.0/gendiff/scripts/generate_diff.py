#!/usr/bin/env python
import gendiff
import json

print(gendiff.parser_args)



